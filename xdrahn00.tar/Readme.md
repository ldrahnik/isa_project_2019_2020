DNS Resolver
============



TODO:

1) chyba, vypisuji TTL 0 místo TTL 14400 atp. u všech dotazů

